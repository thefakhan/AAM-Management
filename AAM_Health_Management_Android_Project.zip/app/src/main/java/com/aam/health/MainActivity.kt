package com.aam.health

import android.app.Activity
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val webView = WebView(this)
        webView.webViewClient = WebViewClient()
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.loadUrl("file:///android_asset/index.html")
        setContentView(webView)
    }
    override fun onBackPressed() {
        val wv = window.decorView.findFocus()
        if (wv is WebView && wv.canGoBack()) wv.goBack() else super.onBackPressed()
    }
}
